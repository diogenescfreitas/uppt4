WinSSHTerm is a tabbed SSH solution for Windows, combining PuTTY/KiTTY, WinSCP and VcXsrv. WinSSHTerm requires .NET Framework 4.0 or later.
Copyright � 2015-22 P-St Software (http://winsshterm.blogspot.com)

WinSSHTerm is freeware. It has no restrictions and is free for private and commercial use.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER 'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

DockPanel Suite (dockpanelsuite.com)
Copyright � 2007 Weifen Luo (MIT License)

Magic Library (dotnetmagic.com)
Copyright � 2003 Crownwood Consulting Ltd.

Vista TaskDialog Wrapper and Emulator
Copyright � 2009 Hedley Muscroft (CPOL, codeproject.com/info/CPOL.zip)

Modern UI Icons (ModernUIIcons.com)
Copyright � 2012 Austin Andrews (CC, creativecommons.org/licenses/by-nd/3.0/)

protobuf-net (github.com/mgravell/protobuf-net)
Copyright � 2008 Marc Gravell (Apache License, apache.org/licenses/LICENSE-2.0)

ZipStorer (github.com/jaime-olivares/zipstorer)
Copyright � 2016 Jaime Olivares (MIT License)

Registry Export File (.reg) Parser
Copyright � 2017 Henryk Filipowicz (CPOL, codeproject.com/info/CPOL.zip)